// Replace with a valid MapBox token
export const MAPBOX_TOKEN = 'pk.eyJ1IjoiYm9sdC1kZW1vIiwiYSI6ImNsdHBhMXN3czB4Z2wyam1ydzBtNm5xeHIifQ.XlJBaegxzHCzuZFPRLKHWQ';

export const mapConfig = {
  initialViewState: {
    longitude: -122.4,
    latitude: 37.8,
    zoom: 11
  },
  style: {
    width: '100%',
    height: '400px',
    position: 'relative' as const
  },
  mapStyle: 'mapbox://styles/mapbox/light-v11' // Changed to light style for better visibility
};