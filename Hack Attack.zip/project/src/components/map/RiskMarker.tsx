import React from 'react';
import { Marker } from 'react-map-gl';
import { AlertTriangle } from 'lucide-react';
import type { DisasterData } from '../../types';

interface RiskMarkerProps {
  risk: DisasterData;
}

const RiskMarker: React.FC<RiskMarkerProps> = ({ risk }) => {
  const getRiskColor = (impact: number) => {
    if (impact > 0.7) return 'text-red-500';
    if (impact > 0.4) return 'text-yellow-500';
    return 'text-green-500';
  };

  return (
    <Marker
      longitude={risk.location.lng}
      latitude={risk.location.lat}
    >
      <div className="relative group">
        <AlertTriangle 
          className={`w-6 h-6 ${getRiskColor(risk.impact)} cursor-pointer transition-transform hover:scale-110`}
        />
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-white rounded shadow-lg
                       opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
          <p className="text-sm font-medium">{risk.type.charAt(0).toUpperCase() + risk.type.slice(1)}</p>
          <p className="text-xs text-gray-500">Risk Level: {(risk.impact * 100).toFixed(0)}%</p>
        </div>
      </div>
    </Marker>
  );
};

export default RiskMarker;