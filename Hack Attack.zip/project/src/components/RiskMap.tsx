import React, { useState } from 'react';
import Map, { NavigationControl } from 'react-map-gl';
import type { DisasterData } from '../types';
import { MAPBOX_TOKEN, mapConfig } from '../config/mapbox';
import RiskMarker from './map/RiskMarker';
import LoadingSpinner from './common/LoadingSpinner';
import ErrorBoundary from './common/ErrorBoundary';
import 'mapbox-gl/dist/mapbox-gl.css';

interface RiskMapProps {
  risks: DisasterData[];
}

const RiskMap: React.FC<RiskMapProps> = ({ risks }) => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <ErrorBoundary>
      <div className="relative w-full h-[400px] rounded-lg overflow-hidden">
        {isLoading && <LoadingSpinner />}
        <Map
          mapboxAccessToken={MAPBOX_TOKEN}
          initialViewState={mapConfig.initialViewState}
          style={mapConfig.style}
          mapStyle={mapConfig.mapStyle}
          onLoad={() => setIsLoading(false)}
          reuseMaps
        >
          <NavigationControl position="top-right" />
          {risks.map((risk, index) => (
            <RiskMarker key={index} risk={risk} />
          ))}
        </Map>
      </div>
    </ErrorBoundary>
  );
};

export default RiskMap;