import React from 'react';
import { Shield, Clock, DollarSign } from 'lucide-react';
import type { MitigationStrategy } from '../types';

interface MitigationStrategiesProps {
  strategies: MitigationStrategy[];
}

const MitigationStrategies: React.FC<MitigationStrategiesProps> = ({ strategies }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {strategies.map((strategy) => (
        <div key={strategy.id} className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-6 h-6 text-blue-600" />
            <h3 className="text-lg font-semibold">{strategy.title}</h3>
          </div>
          <p className="text-gray-600 mb-4">{strategy.description}</p>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{strategy.implementationTime}</span>
            </div>
            <div className="flex items-center gap-1">
              <DollarSign className="w-4 h-4" />
              <span>${strategy.estimatedCost.toLocaleString()}</span>
            </div>
          </div>
          <div className={`mt-4 inline-block px-3 py-1 rounded-full text-sm
            ${strategy.priority === 'high' ? 'bg-red-100 text-red-800' :
              strategy.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
              'bg-green-100 text-green-800'}`}>
            {strategy.priority.charAt(0).toUpperCase() + strategy.priority.slice(1)} Priority
          </div>
        </div>
      ))}
    </div>
  );
};

export default MitigationStrategies;