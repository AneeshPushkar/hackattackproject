export interface DisasterData {
  type: 'flood' | 'earthquake' | 'storm';
  probability: number;
  impact: number;
  location: {
    lat: number;
    lng: number;
  };
}

export interface PredictionModel {
  predict: (data: any) => Promise<DisasterData>;
}

export interface MitigationStrategy {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  estimatedCost: number;
  implementationTime: string;
}