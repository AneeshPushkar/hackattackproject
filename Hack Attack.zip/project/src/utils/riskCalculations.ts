export const calculateRiskLevel = (probability: number, impact: number): number => {
  return probability * impact;
};

export const getRiskCategory = (riskLevel: number): 'low' | 'medium' | 'high' => {
  if (riskLevel > 0.7) return 'high';
  if (riskLevel > 0.4) return 'medium';
  return 'low';
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};