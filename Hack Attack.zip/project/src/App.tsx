import React, { useState, useEffect } from 'react';
import { DisasterPredictionModel } from './services/predictionModel';
import RiskMap from './components/RiskMap';
import RiskMetrics from './components/RiskMetrics';
import MitigationStrategies from './components/MitigationStrategies';
import { AlertOctagon, Brain, Shield } from 'lucide-react';
import type { DisasterData, MitigationStrategy } from './types';

function App() {
  const [risks, setRisks] = useState<DisasterData[]>([]);
  const [strategies, setStrategies] = useState<MitigationStrategy[]>([]);

  // Simulated data for demonstration
  useEffect(() => {
    setRisks([
      {
        type: 'flood',
        probability: 0.8,
        impact: 0.9,
        location: { lat: 37.7749, lng: -122.4194 }
      },
      {
        type: 'earthquake',
        probability: 0.6,
        impact: 0.7,
        location: { lat: 37.7858, lng: -122.4064 }
      }
    ]);

    setStrategies([
      {
        id: '1',
        title: 'Flood Defense Infrastructure',
        description: 'Implementation of advanced flood barriers and drainage systems in high-risk areas',
        priority: 'high',
        estimatedCost: 2500000,
        implementationTime: '18 months'
      },
      {
        id: '2',
        title: 'Earthquake-Resistant Building Retrofitting',
        description: 'Structural reinforcement of existing buildings to withstand seismic activity',
        priority: 'medium',
        estimatedCost: 1800000,
        implementationTime: '24 months'
      },
      {
        id: '3',
        title: 'Early Warning System Enhancement',
        description: 'Upgrade of city-wide sensors and alert systems for faster disaster response',
        priority: 'high',
        estimatedCost: 900000,
        implementationTime: '12 months'
      }
    ]);
  }, []);

  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Flood Risk',
        data: [0.3, 0.5, 0.7, 0.8, 0.6, 0.4],
        borderColor: 'rgb(53, 162, 235)',
        tension: 0.3
      },
      {
        label: 'Earthquake Risk',
        data: [0.4, 0.4, 0.5, 0.6, 0.6, 0.7],
        borderColor: 'rgb(255, 99, 132)',
        tension: 0.3
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-blue-600 text-white p-4">
        <div className="container mx-auto flex items-center gap-2">
          <AlertOctagon className="w-8 h-8" />
          <h1 className="text-2xl font-bold">Smart City Disaster Risk Assessment</h1>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold">Risk Assessment</h2>
            </div>
            <RiskMap risks={risks} />
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <RiskMetrics data={chartData} />
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold">Mitigation Strategies</h2>
          </div>
          <MitigationStrategies strategies={strategies} />
        </div>
      </main>
    </div>
  );
}

export default App;