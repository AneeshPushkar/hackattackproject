import React from 'react';

interface RiskLevelProps {
  level: 'Low' | 'Medium' | 'High' | 'Extreme';
}

const RiskLevel: React.FC<RiskLevelProps> = ({ level }) => {
  const colors = {
    Low: 'bg-green-100 text-green-800',
    Medium: 'bg-yellow-100 text-yellow-800',
    High: 'bg-orange-100 text-orange-800',
    Extreme: 'bg-red-100 text-red-800'
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colors[level]}`}>
      {level}
    </span>
  );
};

export default RiskLevel;