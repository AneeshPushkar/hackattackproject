import React from 'react';
import { Phone, AlertTriangle, Flame, Heart } from 'lucide-react';

const EmergencyContacts: React.FC = () => {
  const contacts = [
    { name: 'Emergency Services', number: '911', icon: AlertTriangle },
    { name: 'Fire Department', number: '911', icon: Flame },
    { name: 'Medical Emergency', number: '911', icon: Heart },
    { name: 'Disaster Hotline', number: '1-800-RED-CROSS', icon: Phone },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">Emergency Contacts</h3>
      <div className="space-y-4">
        {contacts.map((contact, index) => {
          const Icon = contact.icon;
          return (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Icon className="w-5 h-5 text-red-500 mr-3" />
                <span className="text-gray-700">{contact.name}</span>
              </div>
              <span className="font-semibold text-blue-600">{contact.number}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default EmergencyContacts;