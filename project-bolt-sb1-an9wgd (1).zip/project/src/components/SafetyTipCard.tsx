import React from 'react';
import { SafetyTip } from '../types';
import { AlertCircle } from 'lucide-react';

interface SafetyTipCardProps {
  tip: SafetyTip;
}

const SafetyTipCard: React.FC<SafetyTipCardProps> = ({ tip }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        <AlertCircle className="w-5 h-5 text-yellow-500 mr-2" />
        <h4 className="text-lg font-semibold text-gray-900">{tip.title}</h4>
      </div>
      <p className="text-gray-600">{tip.description}</p>
      <div className="mt-4">
        <span className="text-sm text-blue-600 font-medium">{tip.disasterType}</span>
      </div>
    </div>
  );
};

export default SafetyTipCard;