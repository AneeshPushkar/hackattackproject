import React from 'react';
import { DisasterType } from '../types';
import RiskLevel from './RiskLevel';
import { 
  Waves, 
  Droplets, 
  Wind, 
  Flame,
  AlertCircle 
} from 'lucide-react';

interface DisasterCardProps {
  disaster: DisasterType;
}

const iconMap = {
  Waves,
  Droplets,
  Wind,
  Flame
};

const DisasterCard: React.FC<DisasterCardProps> = ({ disaster }) => {
  const Icon = iconMap[disaster.icon as keyof typeof iconMap] || AlertCircle;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow border-l-4"
         style={{ borderLeftColor: getRiskColor(disaster.riskLevel) }}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Icon className="w-6 h-6 mr-2" style={{ color: getRiskColor(disaster.riskLevel) }} />
          <h3 className="text-xl font-semibold text-gray-900">{disaster.name}</h3>
        </div>
        <RiskLevel level={disaster.riskLevel} />
      </div>
      <p className="text-gray-600">{disaster.description}</p>
      <div className="mt-4 text-sm text-gray-500">
        Location: {disaster.coordinates[0].toFixed(2)}°N, {disaster.coordinates[1].toFixed(2)}°W
      </div>
    </div>
  );
};

const getRiskColor = (riskLevel: string): string => {
  const colors = {
    Low: '#10B981',
    Medium: '#F59E0B',
    High: '#EF4444',
    Extreme: '#7F1D1D'
  };
  return colors[riskLevel as keyof typeof colors] || '#6B7280';
};

export default DisasterCard;