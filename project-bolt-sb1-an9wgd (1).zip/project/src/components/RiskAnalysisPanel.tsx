import React from 'react';
import { RiskAnalysis } from '../types';
import RiskLevel from './RiskLevel';

interface RiskAnalysisPanelProps {
  location: string;
  risks: RiskAnalysis[];
}

const RiskAnalysisPanel: React.FC<RiskAnalysisPanelProps> = ({ location, risks }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">
        Risk Analysis for {location}
      </h3>
      <div className="space-y-6">
        {risks.map((risk, index) => (
          <div key={index} className="border-b pb-4 last:border-b-0 last:pb-0">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-medium text-gray-800">{risk.disasterType}</h4>
              <RiskLevel level={risk.riskLevel} />
            </div>
            <div className="mb-3">
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="h-2.5 rounded-full"
                  style={{
                    width: `${risk.probability}%`,
                    backgroundColor: getRiskColor(risk.riskLevel)
                  }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Probability: {risk.probability.toFixed(1)}%
              </p>
            </div>
            <div className="mt-3">
              <h5 className="text-sm font-medium text-gray-700 mb-2">Precautions:</h5>
              <ul className="list-disc list-inside space-y-1">
                {risk.precautions.map((precaution, idx) => (
                  <li key={idx} className="text-sm text-gray-600">{precaution}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const getRiskColor = (riskLevel: string): string => {
  const colors = {
    Low: '#10B981',
    Medium: '#F59E0B',
    High: '#EF4444',
    Extreme: '#7F1D1D'
  };
  return colors[riskLevel as keyof typeof colors] || '#6B7280';
};

export default RiskAnalysisPanel;