import React from 'react';
import { MapContainer, TileLayer, Circle, Popup, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { DisasterType, SearchResult } from '../types';
import { icon } from 'leaflet';

interface MapProps {
  disasters: DisasterType[];
  searchResult: SearchResult | null;
}

const getRiskColor = (riskLevel: string): string => {
  const colors = {
    Low: '#10B981',
    Medium: '#F59E0B',
    High: '#EF4444',
    Extreme: '#7F1D1D'
  };
  return colors[riskLevel as keyof typeof colors] || '#6B7280';
};

// Fix for default marker icon in react-leaflet
const defaultIcon = icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

const Map: React.FC<MapProps> = ({ disasters, searchResult }) => {
  const centerUS: [number, number] = [39.8283, -98.5795];

  return (
    <div className="h-[500px] w-full rounded-lg overflow-hidden shadow-lg">
      <MapContainer
        center={searchResult?.coordinates || centerUS}
        zoom={searchResult ? 8 : 4}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {disasters.map((disaster) => (
          <Circle
            key={disaster.id}
            center={disaster.coordinates}
            radius={disaster.radius * 1000}
            pathOptions={{
              color: getRiskColor(disaster.riskLevel),
              fillColor: getRiskColor(disaster.riskLevel),
              fillOpacity: 0.3
            }}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-bold text-lg">{disaster.name}</h3>
                <p className="text-sm text-gray-600">{disaster.description}</p>
                <span className="inline-block mt-2 px-2 py-1 text-xs font-semibold rounded-full"
                      style={{ backgroundColor: getRiskColor(disaster.riskLevel) + '20', color: getRiskColor(disaster.riskLevel) }}>
                  {disaster.riskLevel} Risk
                </span>
              </div>
            </Popup>
          </Circle>
        ))}
        {searchResult && (
          <Marker 
            position={searchResult.coordinates}
            icon={defaultIcon}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-bold text-lg">Searched Location</h3>
                <p className="text-sm text-gray-600">{searchResult.displayName}</p>
              </div>
            </Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
};

export default Map;