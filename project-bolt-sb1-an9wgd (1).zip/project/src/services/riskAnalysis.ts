import { DisasterType, RiskAnalysis } from '../types';

export function analyzeLocationRisks(
  latitude: number,
  longitude: number,
  disasters: DisasterType[]
): RiskAnalysis[] {
  return disasters.map(disaster => {
    const distance = calculateDistance(
      latitude,
      longitude,
      disaster.coordinates[0],
      disaster.coordinates[1]
    );
    
    const probability = calculateProbability(distance, disaster.radius);
    
    return {
      disasterType: disaster.name,
      probability,
      riskLevel: getRiskLevelFromProbability(probability),
      precautions: getPrecautionsForDisaster(disaster.name)
    };
  });
}

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function calculateProbability(distance: number, radius: number): number {
  if (distance > radius) return 0;
  return Math.max(0, Math.min(100, (1 - distance / radius) * 100));
}

function getRiskLevelFromProbability(probability: number): 'Low' | 'Medium' | 'High' | 'Extreme' {
  if (probability < 25) return 'Low';
  if (probability < 50) return 'Medium';
  if (probability < 75) return 'High';
  return 'Extreme';
}

function getPrecautionsForDisaster(disasterType: string): string[] {
  const precautions: Record<string, string[]> = {
    Earthquake: [
      'Stay away from windows and exterior walls',
      'Drop, cover, and hold on under sturdy furniture',
      'Have an emergency kit ready',
      'Know the safe spots in each room'
    ],
    Flood: [
      'Move to higher ground immediately',
      'Avoid walking or driving through flood waters',
      'Keep emergency supplies ready',
      'Monitor local news and weather updates'
    ],
    Hurricane: [
      'Board up windows and secure loose items',
      'Have a evacuation plan ready',
      'Stock up on non-perishable food and water',
      'Keep important documents in a waterproof container'
    ],
    Wildfire: [
      'Create a defensible space around your home',
      'Have an evacuation plan ready',
      'Keep emergency supplies accessible',
      'Monitor air quality and local alerts'
    ]
  };
  
  return precautions[disasterType] || ['Stay informed about local emergency procedures'];
}