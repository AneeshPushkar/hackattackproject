import { SearchResult } from '../types';

export async function searchLocation(query: string): Promise<SearchResult | null> {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
    );
    const data = await response.json();
    
    if (data && data[0]) {
      return {
        coordinates: [parseFloat(data[0].lat), parseFloat(data[0].lon)],
        displayName: data[0].display_name
      };
    }
    return null;
  } catch (error) {
    console.error('Error searching location:', error);
    return null;
  }
}