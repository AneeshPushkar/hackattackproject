import { DisasterType } from '../types';

export const disasters: DisasterType[] = [
  {
    id: '1',
    name: 'Earthquake',
    description: 'High seismic activity detected in the region with potential for significant tremors.',
    riskLevel: 'High',
    icon: 'Waves',
    coordinates: [34.0522, -118.2437], // Los Angeles
    radius: 50
  },
  {
    id: '2',
    name: 'Flood',
    description: 'Elevated risk of flooding due to heavy rainfall and river overflow.',
    riskLevel: 'Medium',
    icon: 'Droplets',
    coordinates: [29.7604, -95.3698], // Houston
    radius: 30
  },
  {
    id: '3',
    name: 'Hurricane',
    description: 'Tropical storm system approaching with potential to develop into a hurricane.',
    riskLevel: 'Extreme',
    icon: 'Wind',
    coordinates: [25.7617, -80.1918], // Miami
    radius: 100
  },
  {
    id: '4',
    name: 'Wildfire',
    description: 'Extreme fire danger due to dry conditions and high temperatures.',
    riskLevel: 'High',
    icon: 'Flame',
    coordinates: [38.5816, -121.4944], // Sacramento
    radius: 40
  }
];