import { SafetyTip } from '../types';

export const safetyTips: SafetyTip[] = [
  {
    id: '1',
    disasterType: 'Earthquake',
    title: 'Drop, Cover, and Hold On',
    description: 'Drop to the ground, take cover under a sturdy desk or table, and hold on until the shaking stops.'
  },
  {
    id: '2',
    disasterType: 'Flood',
    title: 'Move to Higher Ground',
    description: 'Evacuate to higher ground immediately if there\'s a flood warning.'
  },
  {
    id: '3',
    disasterType: 'Hurricane',
    title: 'Secure Your Home',
    description: 'Board up windows and secure loose outdoor items before the hurricane arrives.'
  },
  {
    id: '4',
    disasterType: 'Wildfire',
    title: 'Create Defensible Space',
    description: 'Maintain a buffer zone between your home and surrounding vegetation.'
  }
];