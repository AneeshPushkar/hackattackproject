export interface DisasterType {
  id: string;
  name: string;
  description: string;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Extreme';
  icon: string;
  coordinates: [number, number];
  radius: number;
}

export interface SafetyTip {
  id: string;
  disasterType: string;
  title: string;
  description: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  number: string;
  type: 'Police' | 'Fire' | 'Medical' | 'Disaster Response';
}

export interface MapMarker {
  coordinates: [number, number];
  type: string;
  riskLevel: string;
}

export interface SearchResult {
  coordinates: [number, number];
  displayName: string;
}

export interface RiskAnalysis {
  disasterType: string;
  probability: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Extreme';
  precautions: string[];
}