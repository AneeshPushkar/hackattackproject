import React, { useState } from 'react';
import { AlertOctagon } from 'lucide-react';
import DisasterCard from './components/DisasterCard';
import SafetyTipCard from './components/SafetyTipCard';
import EmergencyContacts from './components/EmergencyContacts';
import Map from './components/Map';
import SearchBar from './components/SearchBar';
import RiskAnalysisPanel from './components/RiskAnalysisPanel';
import { disasters } from './data/disasters';
import { safetyTips } from './data/safetyTips';
import { searchLocation } from './services/geocoding';
import { analyzeLocationRisks } from './services/riskAnalysis';
import { SearchResult, RiskAnalysis } from './types';

function App() {
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [riskAnalysis, setRiskAnalysis] = useState<RiskAnalysis[] | null>(null);

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    try {
      const result = await searchLocation(query);
      if (result) {
        setSearchResult(result);
        const risks = analyzeLocationRisks(
          result.coordinates[0],
          result.coordinates[1],
          disasters
        );
        setRiskAnalysis(risks);
      }
    } catch (error) {
      console.error('Error during search:', error);
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center">
            <AlertOctagon className="w-8 h-8 text-red-600 mr-3" />
            <h1 className="text-3xl font-bold text-gray-900">Natural Disaster Risk Management</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 gap-8">
          <section className="flex flex-col items-center space-y-6">
            <SearchBar onSearch={handleSearch} isLoading={isLoading} />
            <Map 
              disasters={disasters} 
              searchResult={searchResult}
            />
          </section>

          {searchResult && riskAnalysis && (
            <section>
              <RiskAnalysisPanel
                location={searchResult.displayName}
                risks={riskAnalysis}
              />
            </section>
          )}

          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Active Disaster Risks</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {disasters.map(disaster => (
                <DisasterCard key={disaster.id} disaster={disaster} />
              ))}
            </div>
          </section>

          <section className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Safety Guidelines</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {safetyTips.map(tip => (
                <SafetyTipCard key={tip.id} tip={tip} />
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Emergency Resources</h2>
            <EmergencyContacts />
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;