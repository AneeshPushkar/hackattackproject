import React from 'react';
import { Shield, AlertCircle } from 'lucide-react';
import { MitigationStrategy } from '../types';

interface MitigationStrategiesProps {
  strategies: MitigationStrategy[];
}

export const MitigationStrategies: React.FC<MitigationStrategiesProps> = ({ strategies }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="text-green-500" />
        <h2 className="text-xl font-bold">Mitigation Strategies</h2>
      </div>

      <div className="space-y-4">
        {strategies.map((strategy) => (
          <div
            key={strategy.id}
            className="border rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold">{strategy.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{strategy.description}</p>
              </div>
              <span className={`
                px-2 py-1 rounded-full text-xs font-semibold
                ${strategy.priority === 'high' ? 'bg-red-100 text-red-800' :
                  strategy.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'}
              `}>
                {strategy.priority.toUpperCase()}
              </span>
            </div>
            
            <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
              <AlertCircle className="w-4 h-4" />
              <span>{strategy.implementation}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};