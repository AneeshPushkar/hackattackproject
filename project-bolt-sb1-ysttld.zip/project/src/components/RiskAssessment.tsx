import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { DisasterData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

interface RiskAssessmentProps {
  data: DisasterData[];
}

export const RiskAssessment: React.FC<RiskAssessmentProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <AlertTriangle className="text-yellow-500" />
        <h2 className="text-xl font-bold">Risk Assessment</h2>
      </div>
      
      <div className="w-full h-[300px]">
        <BarChart width={600} height={300} data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="type" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="probability" fill="#8884d8" name="Probability" />
          <Bar dataKey="impact" fill="#82ca9d" name="Impact" />
        </BarChart>
      </div>

      <div className="mt-6 space-y-4">
        {data.map((item) => (
          <div key={item.type} className="border-l-4 border-yellow-500 pl-4">
            <h3 className="font-semibold">{item.type} Risk Alert</h3>
            <p className="text-sm text-gray-600">
              Location: {item.location}<br />
              Probability: {item.probability * 100}%<br />
              Potential Impact: {item.impact * 100}%
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};