import React from 'react';
import { MapPin } from 'lucide-react';
import { RiskZone } from '../types';

interface RiskMapProps {
  zones: RiskZone[];
  onZoneSelect: (zone: RiskZone) => void;
}

export const RiskMap: React.FC<RiskMapProps> = ({ zones, onZoneSelect }) => {
  return (
    <div className="relative w-full h-[400px] bg-gray-100 rounded-lg overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80')] bg-cover bg-center opacity-50"></div>
      <div className="absolute inset-0 p-4">
        <div className="grid grid-cols-3 gap-4">
          {zones.map((zone) => (
            <div
              key={zone.id}
              onClick={() => onZoneSelect(zone)}
              className="bg-white/90 p-4 rounded-lg cursor-pointer hover:bg-white/100 transition-all"
            >
              <div className="flex items-center gap-2">
                <MapPin className="text-red-500" />
                <h3 className="font-semibold">{zone.name}</h3>
              </div>
              <div className="mt-2">
                <div className="text-sm">Risk Level: {zone.riskLevel * 100}%</div>
                <div className="text-sm">Threats: {zone.disasterTypes.join(', ')}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};