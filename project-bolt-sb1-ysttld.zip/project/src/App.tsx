import React, { useState } from 'react';
import { RiskMap } from './components/RiskMap';
import { RiskAssessment } from './components/RiskAssessment';
import { MitigationStrategies } from './components/MitigationStrategies';
import { disasterData, mitigationStrategies, riskZones } from './data/mockData';
import { RiskZone } from './types';
import { Brain } from 'lucide-react';

function App() {
  const [selectedZone, setSelectedZone] = useState<RiskZone | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">
              AI Disaster Risk Assessment
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8">
          <section>
            <h2 className="text-xl font-semibold mb-4">Risk Map</h2>
            <RiskMap zones={riskZones} onZoneSelect={setSelectedZone} />
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">Risk Analysis</h2>
              <RiskAssessment data={disasterData} />
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Mitigation Planning</h2>
              <MitigationStrategies strategies={mitigationStrategies} />
            </section>
          </div>

          {selectedZone && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg p-6 max-w-lg w-full">
                <h2 className="text-xl font-bold mb-4">{selectedZone.name}</h2>
                <p className="mb-4">
                  Risk Level: {selectedZone.riskLevel * 100}%<br />
                  Disaster Types: {selectedZone.disasterTypes.join(', ')}
                </p>
                <button
                  onClick={() => setSelectedZone(null)}
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;