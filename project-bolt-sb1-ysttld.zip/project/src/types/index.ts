export interface DisasterData {
  type: string;
  probability: number;
  impact: number;
  location: string;
}

export interface MitigationStrategy {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  implementation: string;
}

export interface RiskZone {
  id: string;
  name: string;
  riskLevel: number;
  disasterTypes: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
}