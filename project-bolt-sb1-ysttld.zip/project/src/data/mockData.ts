import { DisasterData, MitigationStrategy, RiskZone } from '../types';

export const disasterData: DisasterData[] = [
  {
    type: 'Flood',
    probability: 0.75,
    impact: 0.8,
    location: 'Riverside District'
  },
  {
    type: 'Earthquake',
    probability: 0.3,
    impact: 0.9,
    location: 'Downtown'
  },
  {
    type: 'Storm',
    probability: 0.6,
    impact: 0.7,
    location: 'Coastal Area'
  }
];

export const mitigationStrategies: MitigationStrategy[] = [
  {
    id: '1',
    title: 'Flood Defense Infrastructure',
    description: 'Implementation of flood walls and improved drainage systems',
    priority: 'high',
    implementation: 'Immediate action required in Riverside District'
  },
  {
    id: '2',
    title: 'Building Reinforcement',
    description: 'Structural upgrades for earthquake resistance',
    priority: 'medium',
    implementation: 'Phase implementation in Downtown area'
  },
  {
    id: '3',
    title: 'Storm Warning System',
    description: 'Advanced weather monitoring and alert system',
    priority: 'high',
    implementation: 'Deploy across Coastal Area'
  }
];

export const riskZones: RiskZone[] = [
  {
    id: '1',
    name: 'Riverside District',
    riskLevel: 0.8,
    disasterTypes: ['Flood'],
    coordinates: { lat: 34.0522, lng: -118.2437 }
  },
  {
    id: '2',
    name: 'Downtown',
    riskLevel: 0.6,
    disasterTypes: ['Earthquake'],
    coordinates: { lat: 34.0407, lng: -118.2468 }
  },
  {
    id: '3',
    name: 'Coastal Area',
    riskLevel: 0.7,
    disasterTypes: ['Storm', 'Flood'],
    coordinates: { lat: 34.0522, lng: -118.2437 }
  }
];